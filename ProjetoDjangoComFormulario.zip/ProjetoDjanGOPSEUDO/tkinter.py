import tkinter as tk
import sqlite3

# Conecta ao banco do Django (estando na mesma pasta que o manage.py)
conn = sqlite3.connect("db.sqlite3")
cursor = conn.cursor()

def listar():
    listbox.delete(0, tk.END)
    cursor.execute("SELECT id, nome, idade FROM app_pessoa")
    for row in cursor.fetchall():
        listbox.insert(tk.END, f"{row[0]} - {row[1]} ({row[2]} anos)")

# Interface simples
janela = tk.Tk()
janela.title("Listar Pessoas")

listbox = tk.Listbox(janela, width=50)
listbox.pack(padx=10, pady=10)

btn = tk.Button(janela, text="Listar Pessoas", command=listar)
btn.pack(pady=5)

janela.mainloop()