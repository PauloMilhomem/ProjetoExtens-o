from django.apps import AppConfig


class SiteafrConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'siteafr'
